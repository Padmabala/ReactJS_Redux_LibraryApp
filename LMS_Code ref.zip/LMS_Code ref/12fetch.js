fetch('https://jsonplaceholder.typicode.com/todos/1')
    .then(response => {
        // will return a promise
        //console.log(someUndefinedKey());
        return response.json()
    })
    .then(data => {
        console.log(data);
    })
    .catch(e => {
        console.log(e);
    });

    const networkRequest = async (bookId,userId) => {
        
        const headers=new Headers({
            "Content-Type":"application/json"
        });
        try {
            const bookDetail = await fetch('http://127.0.0.1:3005/books/'+bookId);
            const book=await bookDetail.json();
            if(book.availability){
                const response = await fetch('http://127.0.0.1:3005/cart?userID='+userId);    
                const [cart] = await response.json();
                if(!cart.books.includes(book.id))
                {
                const cartRequestConfig={
                    headers,
                    method:'PATCH',
                    body:JSON.stringify({
                        "books": [...cart.books,book.id]
                    })
                }
                debugger;
                const cartResponse = await fetch('http://127.0.0.1:3005/cart?cartID='+parseInt(cart.cartID),cartRequestConfig);
                const cartData= await cartResponse.json();
            console.log(cartData);
                }
                else{
                    console.log("Book is already in the cart");
                    return false;
                }
                
            }
            else{
                console.log("Books not available");
                return false;
            }
    }catch (e) {
        console.log(e);
    }
    };



/**
 * Callbacks
 */
// fetch("url", function() {
//     response.json(data, function() {

//     })
// });

/**
 * Handling async operations with callback
 */
const timeOutCallback = (delayedFunction,) => {
    setTimeout(() => {
        delayedFunction();
    }, 200);
};

timeOutCallback(() => {
    console.log('execute after some timeout');
});

/**
 * Return an Array after timeout
 */
const timeOutPromise = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve([1,2,3,4]);
        }, 0);
    });
};

timeOutPromise()
    .then(response => {
        console.log(response);
    })
    .catch(error => {
        alert(error);
    })


const getTitle = () => {
    return new Promise((resolve, reject) => {
        fetch('https://jsonplaceholder.typicode.com/todos/1')
            .then(response => response.json())
            .then(data => resolve(data.title))
            .catch(e => reject(e));
    });
};

const myAsyncFunction = async () => {
    try {
        const title = await getTitle();
        console.log(`The title is ${title}`);
    } catch(e) {
        console.error("Failed to retrieve title");
    }
};

getTitle()
    .then(title => {
        console.log(`The title is ${title}`);
    })
    .catch(e => {
        console.error("Failed to retrieve title");
    })
